package br.com.mackenzie.Model;

import java.io.Serializable;

public class Usuario implements Serializable {

}
